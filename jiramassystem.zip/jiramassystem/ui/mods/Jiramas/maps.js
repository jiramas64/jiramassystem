cShareSystems.load_pas("Jiramas", [
  "coui://ui/mods/Jiramas/stella/parallelbox.pas",
]);
